#include <stdio.h>
#include <math.h>
#include "winbgi2.h"
#include "rk4.h"

void rhs_fun(double t, double* X, double* F);
void veuler(double t, double* X, double h, int n, void(*fun)(double, double*, double*), double* X1);


void main()
{
	double x0 = 2;
	double y0 = 2;
	double h = 0.001;
	double t_max = 5;

	graphics(800, 600);
	scale(-4, -4, 4, 4);

	double X[2] = { x0, y0 };
	double X1[2];

	for (double t = 0; t < t_max; t += h)
	{
		veuler(t, X, h, 2, rhs_fun, X1);
		printf("t=%lf\n", t);
		printf("x = % lf\t", X[0]);
		printf("y = % lf\n", X[1]);

		setcolor(0.5);
		point(X[0], X[1]);

		for (int i = 0; i < 2; i++)
		{
			X[i] = X1[i];
		}
	}


	X[0] = x0;
	X[1] = y0;


	for (double t = 0; t < t_max; t += h)
	{
		vrk4(t, X, h, 2, rhs_fun, X1);
		printf("t=%lf\n", t);
		printf("x = % lf\t", X[0]);
		printf("y = % lf\n", X[1]);

		setcolor(0); 
		point(X[0], X[1]);

		for (int i = 0; i < 2; i++)
		{
			X[i] = X1[i];
		}
	}

	wait();
	
}

void rhs_fun(double t, double* X, double* F)
{
	double v = pow(sin(t), 0.2);
	F[0] = X[1];
	F[1] = v*(1-X[0]*X[0])*X[1]-X[0];
}

void veuler(double t, double* X, double h, int n, void(*fun)(double, double*, double*), double* X1)
{
	double	ytmp[100];

	fun(t, X, ytmp);
	for (int i = 0; i < n; i++)
	{
		X1[i] = X[i] + h * ytmp[i];
	}

}
